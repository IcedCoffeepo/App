package com.capstone.meduino;

import java.util.ArrayList;
import java.util.List;

public class utils {
  public static String capitalized(String str){
    String[] s = str.split("\\s");
    StringBuilder b = new StringBuilder();
    for(String string : s){
      b.append(String.valueOf(string.charAt(0)).toUpperCase());
      if(string.length() > 1) {
        b.append(string.substring(1).toLowerCase());
      }
      b.append(" ");
    }
    return String.valueOf(b).trim();
  }

  public static boolean containsTrue(boolean... array){
    for(boolean b : array){
      if(b) return true;
    }
    return false;
  }

  public static List<Integer> daysOfWeek(boolean... array){
    ArrayList<Integer> list = new ArrayList<>();
    for(int b = 0; b < array.length; b++){
      if(array[b]){
        list.add(b);
      }
    }
    return list;
  }
}
