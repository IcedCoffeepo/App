package com.capstone.meduino;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.drawerlayout.widget.DrawerLayout;

import com.capstone.meduino.widgets.btn;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class lobby extends Activity {

  FirebaseFirestore fs;
  DrawerLayout main_layout;
  RelativeLayout main;
  ListView drawer;
  SharedPreferences pref;
  String[] days = {
    "Sunday", "Monday", "Tuesday", "Wednesday",
    "Thursdays", "Friday", "Saturday"
  };

  @SuppressLint("CommitPrefEdits")
  @Override
  public void onCreate(@Nullable Bundle bundle) {
    super.onCreate(bundle);
    setTheme(R.style.Theme_MeDuino);
    setContentView(R.layout.main);

    if(FirebaseAuth.getInstance().getCurrentUser() == null){
      startActivity("com.capstone.meduino.MainActivity");
    }

    pref = getSharedPreferences("com.capstone.meduino.PREFERENCES", MODE_PRIVATE);

    // TODO: To setup the firestore for data fetch
    fs = FirebaseFirestore.getInstance();

    // TODO: To setup the required layouts
    main = findViewById(R.id.main);
    drawer = findViewById(R.id.drawer);
    main_layout = findViewById(R.id.main_layout);

    // INFO: main layout information
    main.setGravity(Gravity.CENTER);
    main.setPadding(10, 10, 10, 10);

    // INFO: List adapters
    String[] lists = {
      "Home",
      "Disabled Schedules",
      "Add Medicine Schedule"
    };

    // TODO: To add the list for menu
    ArrayAdapter<String> list = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, lists);
    drawer.setAdapter(list);
    drawer.setOnItemClickListener((adapterView, view, i, l) -> {
      pref.edit().putInt(preferences("CURRENT_LAYOUT"), i).apply();
      setMain();
    });
    setMain();
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    String[] opts = {
      "Settings",
      "Logout"
    };
    for(int i = 0; i < opts.length; i++){
      String opt = opts[i];
      menu.add(i, i, i, opt);
    }
    return super.onCreateOptionsMenu(menu);
  }

  @Override
  public boolean onOptionsItemSelected(@NonNull MenuItem item) {
    switch(item.getItemId()){
      case 0:
        settings();
      break;
      case 1:
        FirebaseAuth.getInstance().signOut();
        pref.edit().clear().apply();
        startActivity("com.capstone.meduino.MainActivity");
      break;
    }
    return super.onOptionsItemSelected(item);
  }

  void startActivity(String name){
    try{
      startActivity(new Intent(this, Class.forName(name)));
      finish();
    }catch (Exception e){
      Log.e("Class Not Found", e.getMessage());
    }
  }

  String preferences(String name){
    return String.format("com.capstone.meduino.preferences.%s", name);
  }

  int currentLayout(){
    return pref.getInt(preferences("CURRENT_LAYOUT"), 0);
  }

  @SuppressLint({"ResourceAsColor", "DefaultLocale"})
  void setMain(){
    main.removeAllViews();
    float[] fl = {
      5, 5, 5, 5,
      5, 5, 5, 5
    };
    ShapeDrawable drawable = new ShapeDrawable(new RoundRectShape(fl, null, null));

    drawable.getPaint().setShadowLayer(10, 5, 5, Color.parseColor("#3D6176"));
    drawable.getPaint().setColor(Color.parseColor("#C4DDDE"));

    if(currentLayout() == 0){
      // INFO: Main Layout
      // TODO: To create a layout for main
      LinearLayout base = new LinearLayout(this);
      base.setOrientation(LinearLayout.VERTICAL);
      base.setBackground(drawable);
      base.setPadding(5, 5, 5, 5);
      base.setGravity(Gravity.CENTER);

      if(pref.getString(preferences("HARDWARE_ID"), "").isEmpty()) {
        TextView text = new TextView(this);
        text.setText("Please enter your hardware ID using the settings option in the menu");
        text.setTextSize(25);
        base.addView(text);
      }else{
        ScrollView sv = new ScrollView(this);
        GridLayout grid = new GridLayout(this);
        getActionBar().setSubtitle("Active Schedules");
        // INFO: Grid
        grid.setColumnCount(2);
        ProgressBar pb = new ProgressBar(this);
        TextView txt = new TextView(this);

        txt.setText("Please wait");
        txt.setTextSize(20);
        txt.setGravity(Gravity.CENTER);

        base.addView(pb);
        base.addView(txt);
        fs.collection("medicine-schedule")
          .whereEqualTo("hardware_id", pref.getString(preferences("HARDWARE_ID"), ""))
          .whereEqualTo("status", true)
          .get()
          .addOnCompleteListener(task -> {
            base.removeView(pb);
            base.removeView(txt);
            if(task.isSuccessful()) {
              if(task.getResult().size() <= 0){
                TextView text = new TextView(this);
                text.setText("There is no active schedule existed or associated with this hardware ID");
                text.setTextSize(25);
                base.addView(text);
                return;
              }
              int x = 0, y = 0;
              for(QueryDocumentSnapshot snap : task.getResult()){
                String med_name = String.valueOf(snap.get("medicine_name"));
                String desc = String.valueOf(snap.get("generic_name"));
                List<Long> dow = (List<Long>) snap.get("day_of_week");

                // TODO: Fix the time
                // INFO: To get the time (hour and minute)
                List<Map<String, Integer>> time = (List<Map<String, Integer>>) snap.get("time");
                assert time != null;
                assert dow != null;
                try {
                  // KEY: Math.toIntExact transfer long data type to integer
                  double amt = (double) snap.get("dose");
                  int[] d =  new int[dow.size()];
                  String[] hr_min = new String[time.size()];
                  for (int i = 0; i < d.length; i++) {
                    d[i] = Math.toIntExact(dow.get(i));
                  }
                  for(int i = 0; i < hr_min.length; i++){
                    hr_min[i] = String.format("%02d:%02d", time.get(i).get("hour"), time.get(i).get("minute"));
                  }

                  LinearLayout block = block(med_name, desc, d, hr_min, amt);
                  GridLayout.LayoutParams params = new GridLayout.LayoutParams(new LinearLayout.LayoutParams((int) (getWindow().getWindowManager().getDefaultDisplay().getWidth() * 0.4f), LinearLayout.LayoutParams.WRAP_CONTENT));
                  params.rowSpec = GridLayout.spec(x);
                  params.columnSpec = GridLayout.spec(y % 2);
                  params.setMargins(10, 10, 10, 10);
                  y++;

                  if ((y % 2) == 0) {
                    x++;
                  }

                  block.setLayoutParams(params);
                  block.setOnClickListener(v -> {
                    AlertDialog.Builder alert = new AlertDialog.Builder(this);
                    alert.setTitle(String.format("Choose Activity with %s", med_name));
                    alert.setMessage("Please select an activity you want to do with this schedule");
                    alert.setPositiveButton("Update", (c, i) -> {
                      update(snap.getId(), String.valueOf(snap.get("medicine_name")), String.valueOf(snap.get("generic_name")), dow, time, amt);
                    });
                    alert.setNegativeButton("Disable", (c, i) -> {
                      ProgressDialog.Builder dialog = new ProgressDialog.Builder(this);
                      dialog.setTitle("Processing");
                      dialog.setMessage("Please wait");
                      dialog.setCancelable(false);
                      dialog.show();
                      Map<String, Object> map = new HashMap<>();
                      map.put("status", false);
                      fs.collection("medicine-schedule")
                        .document(snap.getId())
                        .update(map)
                        .addOnCompleteListener(task1 -> {
                          if(task1.isSuccessful()){
                            Toast.makeText(lobby.this, "The schedule is now disabled", Toast.LENGTH_LONG).show();
                            recreate();
                          }
                        });
                    });
                    alert.setNeutralButton("Cancel", null);
                    alert.setCancelable(true);
                    alert.show();
                  });
                  grid.addView(block);
                }catch(Exception e){
                  Toast.makeText(lobby.this, e.getMessage(), Toast.LENGTH_LONG).show();
                }
              }
            }
          });
        sv.addView(grid);
        main.addView(sv);
      }
      main.addView(base);
    }else if(currentLayout() == 1){
      // TODO: Disabled Schedules
      LinearLayout base = new LinearLayout(this);
      base.setOrientation(LinearLayout.VERTICAL);
      base.setBackground(drawable);
      base.setPadding(5, 5, 5, 5);
      base.setGravity(Gravity.CENTER);

      Log.i("Test", "Test 1");

      if(pref.getString(preferences("HARDWARE_ID"), "").isEmpty()) {
        TextView text = new TextView(this);
        text.setText("Please enter your hardware ID using the settings option in the menu");
        text.setTextSize(25);
        base.addView(text);
      }else{
        getActionBar().setSubtitle("Disabled Schedules");
        ScrollView sv = new ScrollView(this);
        GridLayout grid = new GridLayout(this);
        // INFO: Grid
        grid.setColumnCount(2);
        ProgressBar pb = new ProgressBar(this);
        TextView txt = new TextView(this);

        txt.setText("Please wait");
        txt.setTextSize(20);
        txt.setGravity(Gravity.CENTER);

        base.addView(pb);
        base.addView(txt);
        fs.collection("medicine-schedule")
          .whereEqualTo("hardware_id", pref.getString(preferences("HARDWARE_ID"), ""))
          .whereEqualTo("status", false)
          .get()
          .addOnCompleteListener(task -> {
            base.removeView(pb);
            base.removeView(txt);
            if(task.getResult().size() <= 0){
              TextView text = new TextView(this);
              text.setText("There is no disabled schedule existed or associated with this hardware ID");
              text.setTextSize(25);
              base.addView(text);
              return;
            }
            if(task.isSuccessful()) {
              int x = 0, y = 0;
              for(QueryDocumentSnapshot snap : task.getResult()){
                String med_name = String.valueOf(snap.get("medicine_name"));
                String desc = String.valueOf(snap.get("generic_name"));
                List<Long> dow = (List<Long>) snap.get("day_of_week");

                // TODO: Fix the time
                // INFO: To get the time (hour and minute)
                List<Map<String, Integer>> time = (List<Map<String, Integer>>) snap.get("time");
                assert time != null;
                assert dow != null;
                try {
                  // KEY: Math.toIntExact transfer long data type to integer
                  double amt = (double) snap.get("dose");
                  int[] d =  new int[dow.size()];
                  String[] hr_min = new String[time.size()];
                  for (int i = 0; i < d.length; i++) {
                    d[i] = Math.toIntExact(dow.get(i));
                  }
                  for(int i = 0; i < hr_min.length; i++){
                    hr_min[i] = String.format("%02d:%02d", time.get(i).get("hour"), time.get(i).get("minute"));
                  }

                  LinearLayout block = block(med_name, desc, d, hr_min, amt);
                  GridLayout.LayoutParams params = new GridLayout.LayoutParams(new LinearLayout.LayoutParams((int) (getWindow().getWindowManager().getDefaultDisplay().getWidth() * 0.4f), LinearLayout.LayoutParams.WRAP_CONTENT));
                  params.rowSpec = GridLayout.spec(x);
                  params.columnSpec = GridLayout.spec(y % 2);
                  params.setMargins(10, 10, 10, 10);
                  y++;

                  if ((y % 2) == 0) {
                    x++;
                  }

                  block.setLayoutParams(params);
                  block.setOnClickListener(v -> {
                    AlertDialog.Builder alert = new AlertDialog.Builder(this);
                    alert.setTitle(String.format("Choose Activity with %s", med_name));
                    alert.setMessage("Please select an activity you want to do with this schedule");
                    alert.setPositiveButton("Update", (c, i) -> {
                      update(snap.getId(), String.valueOf(snap.get("medicine_name")), String.valueOf(snap.get("generic_name")), dow, time, amt);
                    });
                    alert.setNegativeButton("Enable", (c, i) -> {
                      ProgressDialog.Builder dialog = new ProgressDialog.Builder(this);
                      dialog.setTitle("Processing");
                      dialog.setMessage("Please wait");
                      dialog.setCancelable(false);
                      dialog.show();
                      Map<String, Object> map = new HashMap<>();
                      map.put("status", true);
                      fs.collection("medicine-schedule")
                        .document(snap.getId())
                        .update(map)
                        .addOnCompleteListener(task1 -> {
                          if(task1.isSuccessful()){
                            Toast.makeText(lobby.this, "The schedule is now re-activated", Toast.LENGTH_LONG).show();
                            recreate();
                          }
                        });
                    });
                    alert.setNeutralButton("Cancel", null);
                    alert.setCancelable(true);
                    alert.show();
                  });
                  grid.addView(block);
                }catch(Exception e){
                  Toast.makeText(lobby.this, e.getMessage(), Toast.LENGTH_LONG).show();
                }
              }
            }
          });
        sv.addView(grid);
        main.addView(sv);
      }
      main.addView(base);
    }else if(currentLayout() == 2){
      // TODO: Add Medicine Schedule
      if(pref.getString(preferences("HARDWARE_ID"), "").isEmpty()) {
        LinearLayout base = new LinearLayout(this);
        TextView text = new TextView(this);
        text.setText("Please enter your hardware ID using the settings option in the menu");
        text.setTextSize(25);
        base.setGravity(Gravity.CENTER);
        base.setOrientation(LinearLayout.VERTICAL);
        base.addView(text);
        main.addView(base);
      }else {
        getActionBar().setSubtitle("Add new schedule");
        LinearLayout base = new LinearLayout(this);
        TextView title = new TextView(this);
        EditText name = new EditText(this);
        EditText generic = new EditText(this);
        EditText amount = new EditText(this);
        GridLayout dow = new GridLayout(this);
        HorizontalScrollView sc = new HorizontalScrollView(this);
        LinearLayout _time = new LinearLayout(this);
        TextView addTime = new TextView(this);
        List<Map<String, Integer>> list = new ArrayList<>();
        btn btn = new btn(this);

        // TODO: Create a data to firebase that contains all the medicine generic name
        // CONT: with related to the category (not all human knows what was the medicine category of it

        // INFO: title
        title.setText("Add Medicine Schedule");
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        title.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // INFO: name
        name.setSingleLine();
        name.setHint("Enter the medicine name");
        name.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // INFO: generic
        generic.setSingleLine();
        generic.setHint("Enter the generic name");
        generic.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // INFO: amount
        amount.setSingleLine();
        amount.setHint("Enter the dosage to take (mg)");
        amount.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        amount.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // INFO: Day of Week
        boolean[] dow_boolean = {
          false, false, false, false,
          false, false, false
        };
        int c = 0;
        for (int i = 0; i < days.length; i++) {
          final int j = i;
          CheckBox cb = new CheckBox(this);
          cb.setText(days[i]);
          GridLayout.LayoutParams params_ = new GridLayout.LayoutParams();
          params_.rowSpec = GridLayout.spec(c - (i % 3));
          params_.columnSpec = GridLayout.spec(i % 3);
          c++;
          cb.setLayoutParams(params_);
          cb.setOnCheckedChangeListener((compoundButton, b) -> {
            dow_boolean[j] = b;
          });
          dow.addView(cb);
        }

        // INFO: time
        _time.setOrientation(LinearLayout.HORIZONTAL);
        sc.addView(_time);

        // INFO: add time
        addTime.setText("Add time");
        addTime.setGravity(Gravity.START);
        addTime.setPadding(5, 10, 5, 10);
        addTime.setTextSize(18);
        addTime.setOnClickListener(v -> {
          time(_time, list);
        });

        // INFO: btn
        btn.setText("Add Schedule");
        btn.setGravity(Gravity.CENTER);
        btn.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        btn.setOnClickListener(view -> {
          if (name.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Medicine name must not be empty", Toast.LENGTH_LONG).show();
            return;
          }
          if (generic.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Generic name must not be empty", Toast.LENGTH_LONG).show();
            return;
          }
          if (amount.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Amount must not be empty", Toast.LENGTH_LONG).show();
            return;
          }
          if (!utils.containsTrue(dow_boolean)) {
            Toast.makeText(this, "There is no active day of week settled to this schedule", Toast.LENGTH_LONG).show();
            return;
          }
          if (list.isEmpty()) {
            Toast.makeText(this, "There is no time set to this schedule", Toast.LENGTH_LONG).show();
            return;
          }

          List<Integer> days_of_week = utils.daysOfWeek(dow_boolean);
          days_of_week.sort(Integer::compareTo);

          ProgressDialog.Builder dialog = new ProgressDialog.Builder(this);
          dialog.setTitle("Processing");
          dialog.setMessage("Please wait");
          dialog.setCancelable(false);
          dialog.show();

          Map<String, Object> maps = new HashMap<>();
          maps.put("generic_name", utils.capitalized(generic.getText().toString()));
          maps.put("medicine_name", utils.capitalized(name.getText().toString()));
          maps.put("hardware_id", pref.getString(preferences("HARDWARE_ID"), ""));
          maps.put("time", list);
          maps.put("day_of_week", days_of_week);
          maps.put("dose", Float.parseFloat(amount.getText().toString()));
          maps.put("status", true);
          fs.collection("medicine-schedule")
            .add(maps)
            .addOnCompleteListener(task -> {
              if (task.isSuccessful()) {
                Toast.makeText(lobby.this, "New Schedule added with this hardware", Toast.LENGTH_LONG).show();
                recreate();
              }
            });
        });

        // INFO: base
        base.setOrientation(LinearLayout.VERTICAL);
        base.setPadding(5, 5, 5, 5);
        base.setGravity(Gravity.CENTER);
        base.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        base.addView(title);
        base.addView(name);
        base.addView(generic);
        base.addView(amount);
        base.addView(dow);
        base.addView(sc);
        base.addView(addTime);
        base.addView(btn);

        main.addView(base);
      }
    }
  }

  void settings(){
    AlertDialog.Builder alert = new AlertDialog.Builder(this);
    ScrollView base = new ScrollView(this);
    LinearLayout main = new LinearLayout(this);
    final EditText hardwareID = new EditText(this);

    hardwareID.setSingleLine();
    hardwareID.setHint("Enter your hardware ID");

    // TODO: To setup the main layout for the scrollview
    main.setOrientation(LinearLayout.VERTICAL);
    main.addView(hardwareID);

    base.addView(main);
    alert.setTitle("Settings");
    alert.setView(base);
    alert.setPositiveButton("Confirm", (d, i) -> {
      pref.edit()
        .putString(preferences("HARDWARE_ID"), hardwareID.getText().toString())
        .putInt(preferences("CURRENT_LAYOUT"), 0).apply();
      recreate();
    });
    alert.setNeutralButton("Cancel", null);
    alert.setCancelable(false);
    alert.show();
  }

  @Override
  public void onBackPressed() {
    AlertDialog.Builder alert = new AlertDialog.Builder(this);
    alert.setTitle("Confirmation");
    alert.setMessage("Are you sure you want to leave the app?");
    alert.setPositiveButton("Yes", (d, i) -> {
      finishAffinity();
    });
    alert.setNegativeButton("No", null);
    alert.show();
  }

  @SuppressLint({"DefaultLocale", "ResourceAsColor"})
  LinearLayout block(String title, String description, int[] dayOfWeek, String[] time, double amt){
    LinearLayout base = new LinearLayout(this);
    TextView _title = new TextView(this, null, android.R.attr.text);
    TextView _desc = new TextView(this);
    TextView others = new TextView(this);
    float[] radii = {
      10, 10, 10, 10,
      10, 10, 10, 10
    };
    ShapeDrawable drawable = new ShapeDrawable(new RoundRectShape(radii, null, null));
    StringBuilder dow = new StringBuilder();
    StringBuilder _time = new StringBuilder();

    drawable.getPaint().setColor(Color.parseColor("#648D8E"));

    for(int d : dayOfWeek){
      dow.append(days[d]).append(", ");
    }
    for(String t : time){
      _time.append(t).append(", ");
    }

    // INFO: title
    _title.setText(title);
    _title.setTextSize(25);
    _title.setGravity(Gravity.CENTER);
    _title.setTextColor(Color.parseColor("#C4DDDE"));

    // INFO: description
    _desc.setText(String.format("%s\n\nAmount intake (mg): %.2f", description, amt));
    _desc.setTextSize(_title.getTextSize() * 0.3f);
    _desc.setGravity(Gravity.CENTER);
    _desc.setTextColor(Color.parseColor("#C4DDDE"));

    // INFO: Others
    others.setText(String.format("During %s every %s", dow.substring(0, dow.length() - 2), _time.substring(0, _time.length() - 2)));
    others.setGravity(Gravity.CENTER);
    others.setTextColor(Color.parseColor("#C4DDDE"));

    base.setOrientation(LinearLayout.VERTICAL);
    base.setBackground(drawable);
    base.setLayoutParams(new LinearLayout.LayoutParams((int) (getWindow().getWindowManager().getDefaultDisplay().getWidth() * 0.3f), LinearLayout.LayoutParams.WRAP_CONTENT));
    base.setGravity(Gravity.CENTER);
    base.setPadding(5, 5, 5, 5);
    base.addView(_title);
    base.addView(_desc);
    base.addView(others);

    return base;
  }

  @SuppressLint("DefaultLocale")
  void time(LinearLayout base, List<Map<String, Integer>> list){
    new TimePickerDialog(this, (v, h, m) -> {
      Map<String, Integer> map = new HashMap<>();
      map.put("hour", h);
      map.put("minute", m);
      if(list.contains(map)){
        Toast.makeText(this, "This schedule is already existed", Toast.LENGTH_LONG).show();
      }else {
        TextView _time = new TextView(this);
        _time.setText(String.format("%02d:%02d", h, m));
        _time.setTextSize(19);
        _time.setPadding(10, 10, 10, 10);
        _time.setOnClickListener(view -> {
          base.removeView(_time);
          list.remove(map);
        });
        list.add(map);
        base.addView(_time);
      }
    }, 6, 0, true).show();
  }

  @SuppressLint("DefaultLocale")
  void update(String id, String medicineName, String genericName, List<Long> dow, List<Map<String, Integer>> hrMin, double amt) {
    AlertDialog.Builder alert = new AlertDialog.Builder(this);
    ScrollView base = new ScrollView(this);
    HorizontalScrollView tb = new HorizontalScrollView(this);
    GridLayout day_of_week = new GridLayout(this);
    LinearLayout main = new LinearLayout(this),
      time_base = new LinearLayout(this);
    final EditText medicine_name = new EditText(this),
      generic_name = new EditText(this),
      dose = new EditText(this);
    TextView addTime = new TextView(this);
    boolean[] dow_bool = {
      false, false, false, false,
      false, false, false
    };

    // INFO: medicine name
    medicine_name.setSingleLine();
    medicine_name.setText(medicineName);
    medicine_name.setHint("Enter medicine name");

    // INFO: generic name
    generic_name.setSingleLine();
    generic_name.setText(genericName);
    generic_name.setHint("Enter generic name");

    // INFO: hours and minutes
    time_base.setOrientation(LinearLayout.HORIZONTAL);
    for(int i = 0; i < hrMin.size(); i++){
      final int j = i;
      TextView timer = new TextView(this);

      timer.setText(String.format("%02d:%02d", hrMin.get(i).get("hour"), hrMin.get(i).get("minute")));
      timer.setPadding(15, 5, 15, 5);
      timer.setTextSize(18);
      timer.setOnClickListener(v -> {
        hrMin.remove(j);
        time_base.removeView(timer);
      });
      time_base.addView(timer);
    }

    // INFO: Day of Week
    int c = 0;
    for (int i = 0; i < days.length; i++) {
      final int j = i;
      CheckBox cb = new CheckBox(this);
      cb.setText(days[i]);
      GridLayout.LayoutParams params_ = new GridLayout.LayoutParams();
      params_.rowSpec = GridLayout.spec(c - (i % 3));
      params_.columnSpec = GridLayout.spec(i % 3);
      c++;
      for(int k = 0; k < dow.size(); k++){
        if(i == dow.get(k)){
          cb.setChecked(true);
          dow_bool[j] = true;
        }
      }
      cb.setLayoutParams(params_);
      cb.setOnCheckedChangeListener((compoundButton, b) -> {
         dow_bool[j] = b;
      });
      day_of_week.addView(cb);
    }

    // INFO dose
    dose.setSingleLine();
    dose.setText(String.valueOf(amt));
    dose.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
    dose.setHint("Enter dosage (mg)");

    // INFO: Add time
    addTime.setText("Add time");
    addTime.setTextSize(18);
    addTime.setOnClickListener(v -> {
      time(time_base, hrMin);
    });

    tb.addView(time_base);

    main.setOrientation(LinearLayout.VERTICAL);
    main.addView(medicine_name);
    main.addView(generic_name);
    main.addView(dose);
    main.addView(day_of_week);
    main.addView(tb);
    main.addView(addTime);
    base.addView(main);

    alert.setTitle("Update Schedule");
    alert.setView(base);
    alert.setPositiveButton("Confirm", (di, i) -> {
      float d = 0;
      if(medicine_name.getText().toString().trim().isEmpty()){
        Toast.makeText(lobby.this, "Medicine name must not be empty", Toast.LENGTH_LONG).show();
        return;
      }
      if(generic_name.getText().toString().trim().isEmpty()){
        Toast.makeText(lobby.this, "Medicine name must not be empty", Toast.LENGTH_LONG).show();
        return;
      }
      if(dose.getText().toString().trim().isEmpty()){
        Toast.makeText(lobby.this, "Medicine name must not be empty", Toast.LENGTH_LONG).show();
        return;
      }
      try{
        d = Float.parseFloat(dose.getText().toString());
      }catch (Exception e){
        Toast.makeText(lobby.this, "This dosage is not a number", Toast.LENGTH_LONG).show();
        return;
      }
      if(d <= 0){
        Toast.makeText(lobby.this, "The dosage must not be equal to zero.", Toast.LENGTH_LONG).show();
        return;
      }

      ProgressDialog.Builder dialog = new ProgressDialog.Builder(this);
      dialog.setTitle("Processing");
      dialog.setMessage("Please wait");
      dialog.setCancelable(false);
      dialog.show();

      Map<String, Object> maps = new HashMap<>();
      maps.put("medicine_name", medicine_name.getText().toString());
      maps.put("generic_name", generic_name.getText().toString());
      maps.put("dose", d);
      maps.put("time", hrMin);
      maps.put("day_of_week", utils.daysOfWeek(dow_bool));

      fs.collection("medicine-schedule")
        .document(id)
        .update(maps)
        .addOnCompleteListener( task -> {
          Toast.makeText(lobby.this, "The schedule is now updated.", Toast.LENGTH_LONG).show();
          recreate();
        });
    });
    alert.setNegativeButton("Cancel", null);
    alert.setCancelable(false);
    AlertDialog a = alert.create();
    a.show();

    if(a.getButton(AlertDialog.BUTTON_POSITIVE) != null) {
      disabledConfirm(a, medicine_name, medicine_name.getText().toString(), generic_name.getText().toString(), dose.getText().toString(), dow_bool, hrMin);
      disabledConfirm(a, generic_name, medicine_name.getText().toString(), generic_name.getText().toString(), dose.getText().toString(), dow_bool, hrMin);
      disabledConfirm(a, dose, medicine_name.getText().toString(), generic_name.getText().toString(), dose.getText().toString(), dow_bool, hrMin);
    }
  }

  void disabledConfirm(AlertDialog alert, EditText et, String name, String generic, String dose, boolean[] bools, List<Map<String, Integer>> time){
    et.addTextChangedListener(new TextWatcher() {
      @Override
      public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

      @Override
      public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        disabled(alert, name, generic, dose, bools, time);
      }

      @Override
      public void afterTextChanged(Editable editable) {}
    });
  }

  void disabled(AlertDialog alert, String name, String generic, String dose, boolean[] bools, List<Map<String, Integer>> time){
    boolean bool = true;
    if(name.trim().isEmpty()){
      bool = false;
    }
    if(generic.trim().isEmpty()) {
      bool = false;
    }
    if(!utils.containsTrue(bools)) {
      bool = false;
    }
    if(dose.trim().isEmpty()){
      bool = false;
    }

    try{
      float d = Float.parseFloat(dose);
      if(d <= 0){
        bool = false;
      }
    }catch(Exception e){
      bool = false;
    }
    if(bool){
      alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#3D6176"));
    }else{
      alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.RED);
    }
    alert.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(bool);
  }
}
