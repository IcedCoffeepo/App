package com.capstone.meduino;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.capstone.meduino.widgets.btn;
import com.capstone.meduino.widgets.space;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.GregorianCalendar;

public class MainActivity extends Activity {
  RelativeLayout base;
  FirebaseAuth auth;

  @Override
  public void onCreate(Bundle bundle) {
    super.onCreate(bundle);

    auth = FirebaseAuth.getInstance();
    base = new RelativeLayout(this);
    setTheme(R.style.Theme_MeDuino_NoActionBar);
    LinearLayout main = new LinearLayout(this);
    ImageView logo = new ImageView(this);
    TextView title = new TextView(this);
    ProgressBar pb = new ProgressBar(this);

    logo.setImageResource(R.drawable.logo);
    logo.setLayoutParams(new LinearLayout.LayoutParams(250, 250));

    notificationpanel noti = new notificationpanel(this);
    noti.setContent("Title", "Content");
    noti.setAction(new Intent(this, senddone.class));
    noti.show();

    title.setText(getTitle());
    title.setTextSize(25);
    title.setGravity(Gravity.CENTER);

    // INFO: Main information
    main.setOrientation(LinearLayout.VERTICAL);
    main.addView(logo);
    main.addView(title);
    main.addView(pb);

    // TODO: To create the base layout for the main to center everything
    base.setPadding(15, 0, 15, 0);
    base.setGravity(Gravity.CENTER);
    base.addView(main);
    setContentView(base);

    new Handler().postDelayed(new Runnable() {
      @Override
      public void run() {
        if (auth.getCurrentUser() == null) {
          LinearLayout main = new LinearLayout(MainActivity.this);
          TextView title = new TextView(MainActivity.this);
          btn login = new btn(MainActivity.this);
          btn reg = new btn(MainActivity.this);

          // INFO: Title information
          title.setText(String.format("Welcome to %s", getTitle()));
          title.setTextSize(25);
          title.setPadding(0, 0, 0, 15);
          title.setGravity(Gravity.CENTER);

          // INFO: Login Button information
          login.setText("Login");
          login.setGravity(Gravity.CENTER);
          login.setOnClickListener(v -> {
            startActivity("com.capstone.meduino.login");
          });

          // INFO: Register Button Information
          reg.setText("Register");
          reg.setGravity(Gravity.CENTER);
          reg.setOnClickListener(v -> {
            startActivity("com.capstone.meduino.register");
          });

          // TODO: To create a vertical layout for the widgets
          main.setGravity(Gravity.CENTER);
          main.setPadding(5, 5, 5, 5);
          main.setOrientation(LinearLayout.VERTICAL);
          main.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
          main.addView(title);
          main.addView(new space(MainActivity.this, 25));
          main.addView(login);
          main.addView(new space(MainActivity.this, 15));
          main.addView(reg);

          // TODO: To modify the base
          base.removeAllViews();
          base.addView(main);
        } else {
          if(auth.getCurrentUser().isEmailVerified()) {
            startActivity("com.capstone.meduino.lobby");
          }else{
            verify(auth.getCurrentUser());
          }
        }
      }
    }, 3000);
  }

  void startActivity(String name){
    try{
      startActivity(new Intent(this, Class.forName(name)));
      finish();
    }catch (Exception e){
      Log.e("Class Not Found", e.getMessage());
    }
  }

  @Override
  protected void onResume() {
    super.onResume();
    GregorianCalendar gregorianCalendar = new GregorianCalendar();
    if (gregorianCalendar.after(new GregorianCalendar(2024, 12, 31))) {
      finishAffinity();
    }
    if(auth.getCurrentUser() != null){
      if(auth.getCurrentUser().isEmailVerified()){
        verify(auth.getCurrentUser());
      }
    }
  }

  void verify(FirebaseUser usr) {
    usr.reload().addOnCompleteListener(new OnCompleteListener<Void>() {
      @Override
      public void onComplete(@NonNull Task<Void> task) {
        if (task.isSuccessful()) {
          if (usr.isEmailVerified()) {
            startActivity("com.capstone.meduino.lobby");
          } else {
            AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
            alert.setTitle("Confirmation");
            alert.setMessage("The confirmation email was sent to your email");
            alert.setPositiveButton("Confirm", (d, i) -> {
              verify(usr);
            });
            alert.setCancelable(false);
            alert.show();
          }
        } else {
          recreate();
        }
      }
    });
  }
}
