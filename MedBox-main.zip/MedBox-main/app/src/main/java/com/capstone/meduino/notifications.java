package com.capstone.meduino;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class notifications extends FirebaseMessagingService{
  @Override
  public void onMessageReceived(@NonNull RemoteMessage message) {
    super.onMessageReceived(message);

    String medUpdate = "";
    if(message.getData().size() > 0){
      // Handler
    }
    if(message.getNotification() != null){
      notificationpanel noti = new notificationpanel(this);
      noti.setContent("Meduino", "The medicine is...");
      noti.show();
    }
  }
}
