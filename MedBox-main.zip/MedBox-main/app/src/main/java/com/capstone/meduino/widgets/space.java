package com.capstone.meduino.widgets;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;


@SuppressLint("ViewConstructor")
public class space extends View {
  public space(Context ctx, int gap){
    super(ctx);
    setLayoutParams(new LinearLayout.LayoutParams(gap, gap));
  }
}
