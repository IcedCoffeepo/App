package com.capstone.meduino;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import com.capstone.meduino.widgets.btn;
import com.capstone.meduino.widgets.space;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import java.util.regex.Pattern;

public class register extends Activity {
  RelativeLayout base;
  EditText email, pass, pw;
  SharedPreferences pref;
  @Override
  public void onCreate(Bundle bundle){
    super.onCreate(bundle);
    setTheme(R.style.Theme_MeDuino_NoActionBar);
    pref = getSharedPreferences("com.capstone.meduino.PREFERENCES", MODE_PRIVATE);

    FirebaseAuth auth = FirebaseAuth.getInstance();
    base = new RelativeLayout(this);

    if(auth.getCurrentUser() != null){
      startActivity("com.capstone.meduino.MainActivity");
      return;
    }

    LinearLayout main = new LinearLayout(this);
    TextView title = new TextView(this);
    email = new EditText(this);
    pass = new EditText(this);
    pw = new EditText(this);
    btn btn = new btn(this);

    // INFO: Title information
    title.setText(String.format("Welcome to %s", getTitle()));
    title.setGravity(Gravity.CENTER);
    title.setTextSize(25);

    // INFO: Email information
    email.setSingleLine();
    email.setHint("Enter your email");
    email.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);

    // INFO: Password information
    pass.setSingleLine();
    pass.setHint("Enter your password");
    pass.setTransformationMethod(new PasswordTransformationMethod());

    // INFO: Password validator information
    pw.setSingleLine();
    pw.setHint("Re-enter your password");
    pw.setTransformationMethod(new PasswordTransformationMethod());

    // INFO: btn information
    btn.setText("Register");
    btn.setOnClickListener(v -> {
      String _email = email.getText().toString();
      String _pass = pass.getText().toString();
      String pass_ = pw.getText().toString();
      String expr = "^[a-zA-Z0-9._%+-]{5,}@[a-zA-Z0-9.-]{5,}\\.[a-zA-Z]{2,}$";

      if(!Pattern.compile(expr).matcher(_email).matches()){
        Toast.makeText(this, "Invalid email address.", Toast.LENGTH_LONG).show();
        return;
      }

      if(_pass.length() < 8){
        Toast.makeText(this, "Invalid password.", Toast.LENGTH_LONG).show();
        return;
      }

      if(!_pass.equals(pass_)){
        Toast.makeText(this, "Password not match.", Toast.LENGTH_LONG).show();
        return;
      }

      auth.createUserWithEmailAndPassword(_email, _pass)
        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
          @Override
          public void onComplete(@NonNull Task<AuthResult> task) {
            try{
              if(task.isSuccessful()) {
                sendVerification(auth.getCurrentUser());
              }else{
                Toast.makeText(register.this, String.valueOf(task.getResult()), Toast.LENGTH_LONG).show();
              }
            }catch (Exception e){
              Toast.makeText(register.this, String.valueOf(e.getMessage()), Toast.LENGTH_LONG).show();
            }
          }
        });
    });

    // TODO: To create the main layout where the widgets are attached
    main.setGravity(Gravity.CENTER);
    main.setOrientation(LinearLayout.VERTICAL);
    main.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    main.addView(title);
    main.addView(email);
    main.addView(new space(this, 20));
    main.addView(pass);
    main.addView(new space(this, 20));
    main.addView(pw);
    main.addView(new space(this, 20));
    main.addView(btn);

    // TODO: To create the base layout where the main was attached
    base.setGravity(Gravity.CENTER);
    base.addView(main);
    setContentView(base);
  }


  @Override
  public void onBackPressed() {
    startActivity("com.capstone.meduino.MainActivity");
  }

  void startActivity(String name){
    try{
      startActivity(new Intent(this, Class.forName(name)));
      finish();
    }catch (Exception e){
      Log.e("Class Not Found", e.getMessage());
    }
  }

  void sendVerification(final FirebaseUser usr){
    if(usr != null){
      usr.sendEmailVerification()
        .addOnCompleteListener(new OnCompleteListener<Void>() {
          @Override
          public void onComplete(@NonNull Task<Void> task) {
            if(task.isSuccessful()){
              AlertDialog.Builder alert = new AlertDialog.Builder(register.this);
              alert.setTitle("Confirmation");
              alert.setMessage("The confirmation email was sent to your email");
              alert.setPositiveButton("Confirm", (d, i) -> {
                verify(usr);
              });
              alert.setCancelable(false);
              alert.show();
            }else{
              Toast.makeText(register.this, "Failed to send verification", Toast.LENGTH_LONG).show();
            }
          }
        });
    }
  }

  void verify(FirebaseUser usr){
    usr.reload().addOnCompleteListener(new OnCompleteListener<Void>() {
      @Override
      public void onComplete(@NonNull Task<Void> task) {
        if(task.isSuccessful()){
          if(usr.isEmailVerified()){
            startActivity("com.capstone.meduino.lobby");
          }else{
            AlertDialog.Builder alert = new AlertDialog.Builder(register.this);
            alert.setTitle("Confirmation");
            alert.setMessage("The confirmation email was sent to your email");
            alert.setPositiveButton("Confirm", (d, i) -> {
              verify(usr);
            });
            alert.setCancelable(false);
            alert.show();
          }
        }else{
          recreate();
        }
      }
    });
  }
}
