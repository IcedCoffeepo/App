package com.capstone.meduino;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;

public class notificationpanel {
    NotificationCompat.Builder notif;
    Context ctx;
    public notificationpanel(Context ctx){
        this.ctx = ctx;
        // Notification Test
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel notif = new NotificationChannel("default_channel_id", "Default Channel", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager man = (NotificationManager) ctx.getSystemService(ctx.NOTIFICATION_SERVICE);
            man.createNotificationChannel(notif);
        }

        notif = new NotificationCompat.Builder(ctx, "default_channel_id")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setSmallIcon(R.drawable.ic_launcher);

    }
    public void setContent(String title, String content) {
        notif.setContentTitle(title);
        notif.setContentText(content);
    }

    public void setAction(Intent intent){
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("message", "This is a notification");

        PendingIntent i = PendingIntent.getActivity(ctx, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        notif.setContentIntent(i);
    }

    public void show(){
        NotificationManager noti = (NotificationManager) ctx.getSystemService(ctx.NOTIFICATION_SERVICE);
        noti.notify(0, notif.build());
    }
}
