package com.capstone.meduino.widgets;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.widget.Button;

@SuppressLint("AppCompatCustomView")
public class btn extends Button {

  public btn(Context ctx){
    super(ctx);
    float[] innerRadii = {
      10, 10, 10, 10,
      10, 10, 10, 10,
    };
    ShapeDrawable drawable = new ShapeDrawable(new RoundRectShape(innerRadii, null, null));
    drawable.getPaint().setColor(Color.parseColor("#deffef"));
    setPadding(0, 0, 0, 0);
    setBackground(drawable);
  }
}
